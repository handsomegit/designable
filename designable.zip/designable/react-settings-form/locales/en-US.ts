export default {
  'en-US': {
    SettingComponents: {
      ValueInput: {
        expression: 'Expression',
      },
      MonacoInput: {
        helpDocument: 'Help Documents',
      },
    },
  },
}
