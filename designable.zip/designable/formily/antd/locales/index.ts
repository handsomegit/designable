import * as AllLocales from './all'

export { AllLocales }
