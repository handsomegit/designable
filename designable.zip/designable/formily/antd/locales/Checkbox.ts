export const CheckboxGroup = {
  'zh-CN': {
    title: '复选框组',
  },
  'en-US': {
    title: 'Checkbox',
  },
  'ko-KR': {
    title: '체크박스',
  },
}
