import { useLayout } from './useLayout'

export const useTheme = () => {
  return useLayout()?.theme
}
