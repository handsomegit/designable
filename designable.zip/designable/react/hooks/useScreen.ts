import { useDesigner } from './useDesigner'

export const useScreen = () => {
  return useDesigner().screen
}
